# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui/ui_roitool_dialog.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ROIToolDialog(object):
    def setupUi(self, ROIToolDialog):
        ROIToolDialog.setObjectName(_fromUtf8("ROIToolDialog"))
        ROIToolDialog.resize(480, 640)
        self.verticalLayout = QtGui.QVBoxLayout(ROIToolDialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.widget = QtGui.QWidget(ROIToolDialog)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.widget.sizePolicy().hasHeightForWidth())
        self.widget.setSizePolicy(sizePolicy)
        self.widget.setObjectName(_fromUtf8("widget"))
        self.gridLayout = QtGui.QGridLayout(self.widget)
        self.gridLayout.setMargin(0)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.combox_vector = QtGui.QComboBox(self.widget)
        self.combox_vector.setObjectName(_fromUtf8("combox_vector"))
        self.gridLayout.addWidget(self.combox_vector, 2, 1, 1, 3)
        self.label_2 = QtGui.QLabel(self.widget)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 2, 0, 1, 1)
        self.combox_field = QtGui.QComboBox(self.widget)
        self.combox_field.setObjectName(_fromUtf8("combox_field"))
        self.gridLayout.addWidget(self.combox_field, 3, 2, 1, 2)
        self.label = QtGui.QLabel(self.widget)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 4)
        self.label_3 = QtGui.QLabel(self.widget)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 1, 0, 1, 1)
        self.combox_raster = QtGui.QComboBox(self.widget)
        self.combox_raster.setObjectName(_fromUtf8("combox_raster"))
        self.gridLayout.addWidget(self.combox_raster, 1, 1, 1, 3)
        self.label_4 = QtGui.QLabel(self.widget)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout.addWidget(self.label_4, 3, 0, 1, 2)
        self.verticalLayout.addWidget(self.widget)
        self.widget_2 = QtGui.QWidget(ROIToolDialog)
        self.widget_2.setObjectName(_fromUtf8("widget_2"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.widget_2)
        self.verticalLayout_2.setMargin(0)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.splitter = QtGui.QSplitter(self.widget_2)
        self.splitter.setOrientation(QtCore.Qt.Vertical)
        self.splitter.setObjectName(_fromUtf8("splitter"))
        self.table_feature = QtGui.QTableWidget(self.splitter)
        self.table_feature.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOn)
        self.table_feature.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.table_feature.setAlternatingRowColors(True)
        self.table_feature.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.table_feature.setObjectName(_fromUtf8("table_feature"))
        self.table_feature.setColumnCount(0)
        self.table_feature.setRowCount(0)
        self.widget_plot = QtGui.QWidget(self.splitter)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.widget_plot.sizePolicy().hasHeightForWidth())
        self.widget_plot.setSizePolicy(sizePolicy)
        self.widget_plot.setMinimumSize(QtCore.QSize(350, 200))
        self.widget_plot.setObjectName(_fromUtf8("widget_plot"))
        self.verticalLayout_2.addWidget(self.splitter)
        self.verticalLayout.addWidget(self.widget_2)
        self.widget_4 = QtGui.QWidget(ROIToolDialog)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.widget_4.sizePolicy().hasHeightForWidth())
        self.widget_4.setSizePolicy(sizePolicy)
        self.widget_4.setObjectName(_fromUtf8("widget_4"))
        self.gridLayout_3 = QtGui.QGridLayout(self.widget_4)
        self.gridLayout_3.setMargin(0)
        self.gridLayout_3.setObjectName(_fromUtf8("gridLayout_3"))
        self.but_update = QtGui.QPushButton(self.widget_4)
        self.but_update.setObjectName(_fromUtf8("but_update"))
        self.gridLayout_3.addWidget(self.but_update, 0, 0, 1, 1)
        self.verticalLayout.addWidget(self.widget_4)

        self.retranslateUi(ROIToolDialog)
        QtCore.QMetaObject.connectSlotsByName(ROIToolDialog)

    def retranslateUi(self, ROIToolDialog):
        ROIToolDialog.setWindowTitle(_translate("ROIToolDialog", "Region of Interest (ROI) Explorer", None))
        self.label_2.setText(_translate("ROIToolDialog", "Vector:", None))
        self.label.setText(_translate("ROIToolDialog", "<html><head/><body><p align=\"center\"><span style=\" font-weight:600;\">Select Data</span></p></body></html>", None))
        self.label_3.setText(_translate("ROIToolDialog", "Raster:", None))
        self.label_4.setText(_translate("ROIToolDialog", "Aggregate features by field:", None))
        self.table_feature.setSortingEnabled(True)
        self.but_update.setText(_translate("ROIToolDialog", "Update", None))

