""" Store data used by application

GUI sets data; plot accesses data
"""
import numpy as np

# Raster information
band_names = []

# ROI information
roi_names = []
